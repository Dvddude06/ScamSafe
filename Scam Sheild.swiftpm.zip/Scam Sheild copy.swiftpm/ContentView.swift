import SwiftUI
import UIKit

struct ContentView: View {
    let customFont = UIFont(name: "Poppins-Bold", size: 20)
    
    private struct Pages: Identifiable {
        let name: String
        let img: String
        let viewName: String
        var id: String {name}
    }
    private let pages: [Pages] = [
        Pages(name: "1. Phishing", img: "lesson1", viewName: "fishing()"),
        Pages(name: "2. Passwords", img: "lesson2", viewName: "pass()"),
        Pages(name: "3. Popups", img: "lesson3", viewName: "popup()")
        ]
    var body: some View {
        
        NavigationView{
            ZStack{
                Rectangle()
                    .foregroundColor(Color(red: 24/255, green: 24/255, blue: 24/255))
                    .ignoresSafeArea()
                ScrollView{
                    VStack(spacing: 15){
                        Image("Logo")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 170,height:110)
                            
                        Rectangle()
                            .frame(width: 360,height: 140)
                            .foregroundColor(Color(red: 79/255, green: 103/255, blue: 75/255))
                            .cornerRadius(22)
                            .overlay(
                                HStack{
                                    VStack{
                                        Text("Not sure if something is a scam? Have it reviewed.")
                                            .foregroundColor(Color.white)
                                            .fontWeight(.bold)
                                        Text("Submit a photo of something you think might be a scam a have it reviewed to find out.")
                                            .font(.system(size:13))
                                            .offset(y: 3)
                                    }
                                    NavigationLink(destination: reportView()){
                                        Rectangle()
                                            .frame(width: 120, height: 60)
                                            .foregroundColor(Color(red: 0/255, green: 236/255, blue: 52/255))
                                            .cornerRadius(22)
                                            .overlay(
                                                HStack{
                                                    Image(systemName:"exclamationmark.triangle.fill")
                                                        .foregroundColor(Color.black)
                                                        .font(.system(size: 25))
                                                    Text("Report A Scam")
                                                        .foregroundColor(Color.black)
                                                        .font(.system(size: 15))
                                                        .fontWeight(.bold)
                                                }
                                            )
                                    }
                                }
                            )
                        NavigationLink(destination: fishing()){
                            //Nice
                            Rectangle()
                                .frame(width: 200, height: 250)
                                .foregroundColor(Color(red: 217/255, green: 217/255, blue: 217/255))
                                .cornerRadius(22)
                                .overlay(
                                    VStack{
                                        Image("lesson1")
                                            .resizable()
                                            .frame(width: 150, height: 150)
                                        
                                        Text("1.Phishing")
                                            .fontWeight(.bold)
                                            .font(.system(size:25))
                                            .foregroundColor(Color.black)
                                        
                                        
                                    }
                                        .padding()
                                )
                        }
                        NavigationLink(destination: pass()){
                            Rectangle()
                                .frame(width: 200, height: 250)
                                .foregroundColor(Color(red: 217/255, green: 217/255, blue: 217/255))
                                .cornerRadius(22)
                                .overlay(
                                    VStack{
                                        Image("lesson2")
                                            .resizable()
                                            .frame(width: 150, height: 150)
                                        
                                        Text("2.Passwords")
                                            .fontWeight(.bold)
                                            .font(.system(size:25))
                                            .foregroundColor(Color.black)
                                        
                                        
                                    }
                                        .padding()
                                )
                        }
                        Spacer()
                        
                    } //end of vstack
                    .padding()
                }
                
                
            } //end of zstack
        } // Nav View
    }
}




//                                 REPORT VIEW!!!!!

struct Submission: Identifiable {
    let id = UUID()
    let name: String
    let description: String
}


struct reportView: View {
    @State private var showPopover = false
    @State private var name = ""
    @State private var description = ""
    @State private var txt = false
    @State private var submissions: [Submission] = []
    
    var body: some View {
        ZStack{
            Rectangle()
                .foregroundColor(Color(red: 24/255, green: 24/255, blue: 24/255))
                .ignoresSafeArea()
            
                VStack(alignment: .leading){
                   
                    HStack{
                        Image(systemName: "exclamationmark.triangle.fill")
                            .font(.system(size: 62))
                            .foregroundColor(Color(red: 0/255, green: 236/255, blue: 52/255))
                            .padding(.top)
                        Spacer()
                        
                        Button {
                            showPopover = true
                        } label: {
                            Rectangle()
                                .frame(width: 160, height: 40)
                                .cornerRadius(22)
                                .overlay(
                                    Text("\(Image(systemName: "clock.arrow.circlepath"))View Previous Reports")
                                        .foregroundColor(Color.black)
                                        .font(.system(size: 12))
                                )
                        }
                        
                    }
                    Text("Report a scam:")
                        .font(.system(size: 45, weight: .bold))
                        .foregroundColor(Color.white)
                        .padding(.bottom, 30)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    Text("Name of the scam:")
                        .foregroundColor(Color.white)
                        .font(.system(size: 17, weight: .bold))
                    TextField("Name:",text: $name)
                        .frame(height: 40)
                        .cornerRadius(16)
                        .textFieldStyle(PlainTextFieldStyle())
                        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color(red: 0/255, green: 236/255, blue: 52/255)))
                        .foregroundColor(Color.white)
                    Text("Describe the scam:")
                        .foregroundColor(Color.white)
                        .font(.system(size: 17, weight: .bold))
                    TextField("Description:",text: $description)
                        .padding()
                        .frame(height: 105)
                        .cornerRadius(16)
                        .textFieldStyle(PlainTextFieldStyle())
                        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color(red: 0/255, green: 236/255, blue: 52/255)))
                        .foregroundColor(Color.white)
                    Button {
                            let submission = Submission(name: name, description: description)
                                submissions.append(submission)
                                name = ""
                                description = ""
                    } label: {
                        Rectangle()
                            .frame(width: 200, height: 50, alignment: .center)
                            .foregroundColor(Color(red: 0/255, green: 236/255, blue: 52/255))
                            .cornerRadius(22)
                            .overlay(
                                Text("\(Image(systemName: "checkmark.circle"))Submit")
                                    .foregroundColor(Color.black)
                                    .font(.system(size: 20))
                            )
                    }
                    Spacer()
                        
                        Rectangle()
                            .frame(width: 350, height: 140)
                            .foregroundColor(Color.yellow)
                            .overlay(
                                HStack{
                                    Image(systemName: "exclamationmark.circle.fill")
                                        .font(.system(size: 60))
                                        .padding()
                                    VStack{
                                        Text("Demo Purposes Only")
                                            .font(.system(size: 20, weight: .bold))
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                            .padding(.trailing)
                                        Text("This report section is for demo purposes only, the submition will stay on device and won't be saved beyond this section")
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                            .font(.system(size: 17))
                                            .padding(.trailing)
                                    }
                                }
                            )
                        
                
                    
                    
                    // POPOVER
                    .popover(isPresented: $showPopover){
                        HStack{
                            Button {
                                showPopover = false
                            } label: {
                                Rectangle()
                                    .frame(width: 160, height: 40)
                                    .cornerRadius(22)
                                    .padding()
                                    .foregroundColor(Color.green)
                                    .overlay(
                                        Text("\(Image(systemName: "escape"))Exit")
                                            .padding()
                                            .foregroundColor(Color(red: 24/255, green: 24/255, blue: 24/255))
                                    )
                            }
                            Spacer()
                        }
                        List(submissions) { submission in
                            VStack(alignment: .leading) {
                                if submission.name != "" {
                                    HStack{
                                        VStack(alignment: .leading){
                                            Text(submission.name)
                                                .font(.headline)
                                                .foregroundColor(Color.green)
                                                .padding()
                                            Text(submission.description)
                                                .foregroundColor(.secondary)
                                                .padding()
                                        }
                                        Spacer()
                                        Text("Status: Not Reviewed")
                                            .foregroundColor(Color.red)
                                    }
                                }
                                
                                
                            }
                        }
                    }
                    
            } // end of VStack
                .padding()
        } // ZStack
    }
}




private struct PhisingList: Identifiable {
    let text: String
    let detailText: String
    var id: String {text}
}
private let phisingList: [PhisingList] = [
    PhisingList( text: "1. Look at what information is exculeded", detailText: "If there isn’t  your name,username or other similar information then it is probably a scam. Additionally if you are being addressed by your email address ( ex.”hello, john73) then it is likely a scam"),
    PhisingList( text: "2. Check the email adress it was sent from", detailText: "Normally most emails come from the company's domain (ex.  @StreamingPlus.com) if it isn’t then it’s better to be careful of any links or files in that email."),
    PhisingList( text: "3. Check on the official website or app", detailText: "if there actually is an important update (ex. package cancelled, credit card declined) it will be on the official app or website, so it’s better to check there before clicking any links or files")
    ]

struct fishing: View {
    @State var rightSym = "Blank"
    @State var wrongSym = "Space"
    @State var border = false
    @State var showBorder = false
    @State var showQuiz1 = false
    
    @State var right2 = ""
    @State var wrong2 = ""
    @State var q2Right = false
    @State var q2Wrong = false
    
    var body: some View {

        NavigationView{
            ZStack{
            Rectangle()
                .foregroundColor(Color(red: 24/255, green: 24/255, blue: 24/255))
                .ignoresSafeArea()
            
                VStack{
                    
                    Text("")
                ScrollView{
                    Text("1.Phishing")
                        .font(.system(size: 40, weight: .bold))
                        .foregroundColor(Color(red: 0/255, green: 236/255, blue: 52/255))
                        
                    Text("Phishing is an attack that aims to take your money or identinty through getting you to give up your information, commonly these are emails or texts pretending to be banks,streaming services and even the government to give up your information.")
                        .foregroundColor(Color.white)
                        .padding()
                    Text("Examples:")
                        .font(.system(size: 30, weight: .bold))
                        .foregroundColor(Color.white)
                    ScrollView(.horizontal){
                    HStack{
                        
                            Image("fishingExample1")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 200, height: 200)
                                .foregroundColor(Color.white)
                                .padding()
                            Image("fishingExample2")
                                .resizable()
                                .frame(width: 200, height: 200)
                                .scaledToFit()
                                .foregroundColor(Color.white)
                                .padding()
                        }
                    
                    }
                    Text("Ways to avoid phishing:")
                        .font(.system(size: 30, weight: .bold))
                        .padding()
                        .foregroundColor(Color.white)
                    ForEach(phisingList) { phisingList in
                        Text(phisingList.text)
                            .font(.system(size: 25, weight: .bold))
                            .foregroundColor(Color(red: 0/255, green: 236/255, blue: 52/255))
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.leading)
                        Text(phisingList.detailText)
                            
                            .foregroundColor(Color.white)
                            .padding(.bottom, 20)
                            .padding(.leading)
                    }
                    Group{
                        Text("Still not sure, then contact that app,website or services support or use the “report a scam” feature and have it reviewed.")
                            .foregroundColor(Color.white)
                            .fontWeight(.bold)
                            .padding()
                        Rectangle()
                            .frame(width: 350, height: 150)
                            .foregroundColor(Color.black)
                            .overlay(
                                HStack{
                                    Text("Test Your Knowledge")
                                        .font(.system(size:25, weight: .bold))
                                        .padding(.leading)
                                        .foregroundColor(Color(red: 0/255, green: 236/255, blue: 52/255))
                                    VStack{
                                        Text("Try the quiz to see if you can tell what is and what isn't phising")
                                            .foregroundColor(Color.white)
                                        Button{
                                            showQuiz1 = true
                                        } label: {
                                            Rectangle()
                                                .frame(width: 200, height: 50, alignment: .center)
                                                .foregroundColor(Color(red: 0/255, green: 236/255, blue: 52/255))
                                                .cornerRadius(22)
                                                .overlay(
                                                    Text("\(Image(systemName: "doc.richtext.fill"))Try the test")
                                                        .foregroundColor(Color.black)
                                                        .font(.system(size: 20))
                                                )
                                        }
                                    } .padding(.trailing)
                                }
                            )
                            .popover(isPresented: $showQuiz1){
                                ScrollView{
                                    VStack{
                                        HStack{
                                            Button {
                                                showQuiz1 = false
                                            } label: {
                                                Rectangle()
                                                    .frame(width: 160, height: 40)
                                                    .cornerRadius(22)
                                                    .padding()
                                                    .foregroundColor(Color.green)
                                                    .overlay(
                                                        Text("\(Image(systemName: "escape"))Exit")
                                                            .padding()
                                                            .foregroundColor(Color(red: 24/255, green: 24/255, blue: 24/255))
                                                    )
                                            }
                                            Spacer()
                                        }
                                        Text("1. Which of these are more likely to be phising?")
                                            .font(.system(size: 25, weight: .bold))
                                            .padding()
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                        
                                        HStack{
                                            Button{
                                                if showBorder == !true {
                                                    rightSym = "check"
                                                    wrongSym = "x"
                                                    border = true
                                                }
                                            } label: {
                                                ZStack{
                                                    Image("quizEx1")
                                                        .resizable()
                                                        .scaledToFit()
                                                        .frame(width: 180,height: 225)
                                                        .border(border ? Color.red : .clear, width: 7)
                                                        .cornerRadius(13)
                                                    Image(wrongSym)
                                                        .resizable()
                                                        .frame(width: 100, height: 100)
                                                }
                                            }
                                            Button{
                                                if border == !true {
                                                    rightSym = "check"
                                                    wrongSym = "x"
                                                    showBorder = true
                                                }
                                            } label: {
                                                ZStack{
                                                    Image("quizEx2")
                                                        .resizable()
                                                        .scaledToFit()
                                                        .frame(width: 180,height: 225)
                                                        .border(showBorder ? Color.green : .clear, width: 7)
                                                        .cornerRadius(13)
                                                    Image(rightSym)
                                                        .resizable()
                                                        .frame(width: 100, height: 100)
                                                }
                                            }
                                        }
                                        
                                        Text("2. What should you do if you think somthing is a phishing \nscam")
                                            .font(.system(size: 25, weight: .bold))
                                            .lineLimit(nil)
                                            .padding()
                                            .padding(.top, 100)
                                        
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                        HStack{
                                            VStack {
                                                Image(right2)
                                                    .resizable()
                                                    .frame(width: 50, height: 50)
                                                Button{
                                                    if q2Wrong == false {
                                                        right2 = "check"
                                                        wrong2 = "x"
                                                        q2Right = true
                                                    }
                                                } label: {
                                                    Rectangle()
                                                        .cornerRadius(22)
                                                        .frame(width: 160, height: 50)
                                                        .foregroundColor(q2Right ? Color.green : Color.black)
                                                        .overlay(Text("Report it and ignore it").foregroundColor(Color.white) .font(.system(size: 13)))
                                                    
                                                    
                                                }
                                            }
                                            VStack{
                                                Image(wrong2)
                                                    .resizable()
                                
                                                    .frame(width: 50, height: 50)
                                                Button{
                                                    if q2Right == false {
                                                        right2 = "check"
                                                        wrong2 = "x"
                                                        q2Wrong = true
                                                    }
                                                } label: {
                                                    Rectangle()
                                                        .cornerRadius(22)
                                                        .frame(width: 160, height: 50)
                                                        .foregroundColor(q2Wrong ? Color.red : Color.black)
                                                        .overlay(Text("Click links to find out").foregroundColor(Color.white) .font(.system(size: 13)))
                                                }
                                            }
                                            
                                        }
                                        
                                        Spacer()
                                    }
                                } // end of popover vstack
                            }
                            // END OF POPOVER
                    }

                    
                } // end of VStack
            } // end of scrollview
        }
        }
    }
}

struct pass: View {
    private struct StrongPass: Identifiable {
        let undTxt: String
        let detTxt: String
        var id: String {undTxt}
    }
    private let strongPass: [StrongPass] = [
     StrongPass(undTxt: "1. Use a password Manager", detTxt: "Use a password manager to generate a password like iCloud keychain autoFill password or use a no password sign in option like sign in with Apple"),
     StrongPass(undTxt: "2. Use Special Characters", detTxt: "Adding a special charchter to your password makes it harder to guess or be hacked"),
     StrongPass(undTxt: "3. Avoid repeating passwords", detTxt: "avoid re-using passwords,this make it so if one of your passwords is compromised then all of your passwords are too.")
    ]
    private struct PassExample: Identifiable {
        let goodPass: String
        let badPass: String
        var id: String {goodPass}
    }
    private let passExample: [PassExample] = [
        PassExample(goodPass: "T$1989*rep6!", badPass: "Taylor1989"),
        PassExample(goodPass: "2%w3rd4Pa$$", badPass: "wordpass123"),
        PassExample(goodPass: "a3Dmin#!3", badPass: "admin")
    ]
    
    @State private var showQuiz2 = false
    
    @State private var right1 = "Blank"
    @State private var wrong1 = "Space"
    @State private var q1Right = false
    @State private var q1Wrong = false
    
    @State private var right2 = ""
    @State private var wrong2 = ""
    @State private var q2Right = false
    @State private var q2Wrong = false
    
    @State private var right3 = ""
    @State private var wrong3 = ""
    @State private var q3Right = false
    @State private var q3Wrong = false
    
    var body: some View {
        NavigationView{
            ZStack{
                Rectangle()
                    .foregroundColor(Color(red: 24/255, green: 24/255, blue: 24/255))
                    .ignoresSafeArea()
                
                VStack(){
                    Text("")
                    ScrollView{
                        
                        Text("2. Passwords")
                            .font(.system(size: 40, weight: .bold))
                            .foregroundColor(Color(red: 0/255, green: 236/255, blue: 52/255))
                        Text("Ways to create a strong password:")
                            .font(.system(size: 25, weight: .bold))
                            .foregroundColor(Color.white)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding()
                        ForEach(strongPass) { strongPass in
                            Text(strongPass.undTxt)
                                .font(.system(size: 25, weight: .bold))
                                .foregroundColor(Color(red: 0/255, green: 236/255, blue: 52/255))
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding()
                            Text(strongPass.detTxt)
                                .padding()
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .foregroundColor(Color.white)
                        }
                        Text("Examples:")
                            .foregroundColor(Color(red: 0/255, green: 236/255, blue: 52/255))
                            .font(.system(size: 30, weight: .bold))
                        HStack{
                            Text("Secure:")
                                .padding()
                                .foregroundColor(Color.white)
                                .font(.system(size: 25,weight: .bold))
                            Spacer()
                            Text("Insecure:")
                                .padding()
                                .foregroundColor(Color.white)
                                .font(.system(size: 25,weight: .bold))
                        }
                            ForEach(passExample) { passExample in
                                HStack{
                                    Text(passExample.goodPass)
                                        .foregroundColor(Color.green)
                                        .font(.system(size: 15,weight: .bold))
                                        .padding()
                                    Spacer()
                                    Text(passExample.badPass)
                                        .foregroundColor(Color.red)
                                        .font(.system(size: 15,weight: .bold))
                                        .padding()
                                }
                            }
                        HStack{
                            Text("Each of the secure passwords have not showed up in any data breach")
                                .foregroundColor(Color.green)
                                .font(.system(size: 22,weight: .bold))
                                .padding()
                            Spacer()
                            Text("Each of the insecure passwords have appered in a data breach more then 400 times")
                                .multilineTextAlignment(.trailing)
                                .foregroundColor(Color.red)
                                .font(.system(size: 23,weight: .bold))
                                .padding()
                                
                        }
                        Text("Data for breaches comes from haveibeenpwned.com, collected as of April,9,2023.")
                            .foregroundColor(Color.white)
                            .font(.system(size: 10))
                        
                        
                        Rectangle()
                            .frame(width: 350, height: 210)
                            .foregroundColor(Color.black)
                            .overlay(
                                VStack{
                            Text("Can you tell what is and isn't a secure password?")
                                .font(.system(size:23, weight: .bold))
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(.leading)
                                .foregroundColor(Color(red: 0/255, green: 236/255, blue: 52/255))
                                Text("Try the quiz to see if you know about secure passwords")
                                    .foregroundColor(Color.white)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .padding(.leading)
                                Button{
                                    showQuiz2 = true
                                } label: {
                                    Rectangle()
                                        .frame(width: 200, height: 50, alignment: .center)
                                        .foregroundColor(Color(red: 0/255, green: 236/255, blue: 52/255))
                                        .cornerRadius(22)
                                        .overlay(
                                            Text("\(Image(systemName: "doc.richtext.fill"))Try these questions")
                                                .foregroundColor(Color.black)
                                                .font(.system(size: 17))
                                        )
                                }
                                    // POPOVER
                                .popover(isPresented: $showQuiz2){
                                    ScrollView{
                                        VStack{
                                            HStack{
                                                Button {
                                                    showQuiz2 = false
                                                } label: {
                                                    Rectangle()
                                                        .frame(width: 160, height: 40)
                                                        .cornerRadius(22)
                                                        .padding()
                                                        .foregroundColor(Color(red: 0/255, green: 236/255, blue: 52/255))
                                                        .overlay(
                                                            Text("\(Image(systemName: "escape"))Exit")
                                                                .padding()
                                                                .foregroundColor(Color(red: 24/255, green: 24/255, blue: 24/255))
                                                        )
                                                }
                                                Spacer()
                                            }
                                            Text("1. Which is the more secure password?")
                                                .font(.system(size: 25, weight: .bold))
                                                .padding()
                                                .frame(maxWidth: .infinity, alignment: .leading)
                                            HStack{
                                                VStack {
                                                    Image(wrong1)
                                                        .resizable()
                                                        .frame(width: 50, height: 50)
                                                    Button{
                                                        if q1Right == false {
                                                            right1 = "check"
                                                            wrong1 = "x"
                                                            q1Wrong = true
                                                        }
                                                    } label: {
                                                        Rectangle()
                                                            .cornerRadius(22)
                                                            .frame(width: 150, height: 50)
                                                            .foregroundColor(q1Wrong ? Color.red : Color.black)
                                                            .overlay(Text("Dragon09").foregroundColor(Color.white) .font(.system(size: 13)))
                                                    }
                                                }
                                                VStack{
                                                    Image(right1)
                                                        .resizable()
                                                        .frame(width: 50, height: 50)
                                                    Button{
                                                        if q1Wrong == false {
                                                            right1 = "check"
                                                            wrong1 = "x"
                                                            q1Right = true
                                                        }
                                                    } label: {
                                                        Rectangle()
                                                            .cornerRadius(22)
                                                            .frame(width: 150, height: 50)
                                                            .foregroundColor(q1Right ? Color.green : Color.black)
                                                            .overlay(Text("o9Dr@g0n&21!").foregroundColor(Color.white) .font(.system(size: 13)))
                                                    }
                                                }
                                                
                                            }
                                            Text("2. Which is the more secure login method?")
                                                .font(.system(size: 25, weight: .bold))
                                                .padding()
                                                .padding(.top, 100)
                                                .frame(maxWidth: .infinity, alignment: .leading)
                                            HStack{
                                                VStack {
                                                    Image(right2)
                                                        .resizable()
                                                        .frame(width: 50, height: 50)
                                                    Button{
                                                        if q2Wrong == false {
                                                            right2 = "check"
                                                            wrong2 = "x"
                                                            q2Right = true
                                                        }
                                                    } label: {
                                                        Rectangle()
                                                            .cornerRadius(22)
                                                            .frame(width: 150, height: 50)
                                                            .foregroundColor(q2Right ? Color.green : Color.black)
                                                            .overlay(Text("Social sign-in options (Sign in with Apple) ").foregroundColor(Color.white) .font(.system(size: 13)))
                                                        
                                                        
                                                    }
                                                }
                                                VStack{
                                                    Image(wrong2)
                                                        .resizable()
                                                        .frame(width: 50, height: 50)
                                                    Button{
                                                        if q2Right == false {
                                                            right2 = "check"
                                                            wrong2 = "x"
                                                            q2Wrong = true
                                                        }
                                                    } label: {
                                                        Rectangle()
                                                            .cornerRadius(22)
                                                            .frame(width: 150, height: 50)
                                                            .foregroundColor(q2Wrong ? Color.red : Color.black)
                                                            .overlay(Text("Manualy Create a password").foregroundColor(Color.white) .font(.system(size: 13)) )
                                                    }
                                                }
                                                
                                            }
                                            
                                            Spacer()
                                            
                                        }
                                        Text("3. Which is the more secure password?")
                                            .font(.system(size: 25, weight: .bold))
                                            .padding()
                                            .padding(.top, 100)
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                        HStack{
                                            VStack {
                                                Image(wrong3)
                                                    .resizable()
                                                    .frame(width: 50, height: 50)
                                                Button{
                                                    if q3Right == false {
                                                        right3 = "check"
                                                        wrong3 = "x"
                                                        q3Wrong = true
                                                    }
                                                } label: {
                                                    Rectangle()
                                                        .cornerRadius(22)
                                                        .frame(width: 150, height: 50)
                                                        .foregroundColor(q1Wrong ? Color.red : Color.black)
                                                        .overlay(Text("John78").foregroundColor(Color.white) .font(.system(size: 13)))
                                                }
                                            }
                                            VStack{
                                                Image(right3)
                                                    .resizable()
                                                    .frame(width: 50, height: 50)
                                                Button{
                                                    if q3Wrong == false {
                                                        right3 = "check"
                                                        wrong3 = "x"
                                                        q3Right = true
                                                    }
                                                } label: {
                                                    Rectangle()
                                                        .cornerRadius(22)
                                                        .frame(width: 150, height: 50)
                                                        .foregroundColor(q3Right ? Color.green : Color.black)
                                                        .overlay(Text("19@j3hN78").foregroundColor(Color.white) .font(.system(size: 13)))
                                                }
                                            }
                                            
                                        }
                                    }
                                } // popover
                                    
                            
                        }
                            )
                        } .padding(.trailing)
                }
            }
        }
    }
}

struct pop: View {
    var body: some View {
        Text("popups/lesson 3")
    }
}
